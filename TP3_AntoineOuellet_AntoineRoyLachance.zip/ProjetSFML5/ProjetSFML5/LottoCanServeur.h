#pragma once
class LottoCanServeur
{

};