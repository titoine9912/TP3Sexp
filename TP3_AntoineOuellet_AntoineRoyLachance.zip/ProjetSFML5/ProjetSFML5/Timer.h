#pragma once
class Timer
{

};