#include <vld.h>
#include "Terminal.h"
int main()
{
	Terminal terminal;
	return terminal.run();
}