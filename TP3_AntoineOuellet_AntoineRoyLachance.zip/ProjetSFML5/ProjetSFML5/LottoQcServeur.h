#pragma once
class LottoQcServeur
{

};